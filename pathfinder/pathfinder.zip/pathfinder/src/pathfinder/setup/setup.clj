(ns pathfinder.setup.setup
  (:gen-class))

(defn init-field
  ([w h]
   (init-field w h 1))
  ([w-size h-size v] ;; w width, h height
   (let [w (take w-size (repeat v))]
     (take h-size (repeat w)))))

(defn render-terrain
  [array]
    (add-rivers (randomize-heights array)))

(defn randomize-heights
  [array width height]
  (let [wbounds (- width 30)
        hbounds (- height 30)
        w (rand-int wbounds)
        h (rand-int hbounds)
        mod-array (randomize-terrain w h)]))

(defn merge-arrays
  [arr1 arr2]
  (fn one? [x] (= x 1))
  (if-not (one? (first arr1)) (one? (first arr2)) ;; assuring it is 1 by X array
    nil
    (loop [narr [] a arr1 b arr2]
      (if (and (zero? (count arr1)) (zero? (count arr2))) ;; assuring that both arrays have been exhausted
        narr
        (let [v1 (if (> (count arr1) 1) (first arr1) 0)
              v2 (if (> (count arr2) 1) (first arr2) 0)]
          (recur (conj narr (+ v1 v2)) (rest a) (rest b)))))))

(defn add-rivers
  [array]
  )

(defn randomize-terrain
  [width height]
  (loop [w width h width buff [] arr []]
    (let [wrand (fn [] (take width (repeatedly #(if (< (rand) 0.5) 2 1))))]
      (take height (repeatedly wrand)))))
