(ns pathfinder.core
  (:gen-class))

(require '[pathfinder.setup.setup :as setup])

(defn -main
  "I don't do a whole lot ... yet."
  [& args]
  (let [arr (setup/render-terrain 31 31)]
    (loop [r 0]
      (if (< r (count arr))
        (do (println (nth arr r))
            (recur (inc r))))))
  (println "Hello, World!"))
