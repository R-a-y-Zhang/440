(ns pathfinder.solver.solver
    (:gen-class))

(defn solve
    [array sw sh fw fh] ;; array, start width, start height, end width, end height
    )

(defn calculate-manhattan
    [array fw fh]
    )
